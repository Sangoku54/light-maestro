// ─── DMX Movement Utilities ───────────────────────────────
// Extracted from dmx-playback.ts — stage-aware pan/tilt clamping + smart movement patterns

export function clampPanToStage(panDmx: number, x: number): number {
  const d = panDmx - 128;
  return 128 + Math.max(-Math.round(x * 128), Math.min(Math.round((1 - x) * 128), d));
}

export function clampTiltToStage(tiltDmx: number, y: number): number {
  const d = tiltDmx - 128;
  return 128 + Math.max(-Math.round(Math.max(0.2, y) * 128), Math.min(Math.round(Math.min(1, y + 0.3) * 128), d));
}

/** Convert a pan/tilt half-sweep in degrees to a DMX offset from center (128).
 *  Pan full sweep = 270° each side, tilt full sweep = 90° each side (see Stage3D conversion). */
export function halfDegToDmxOffset(deg: number, axis: 'pan' | 'tilt'): number {
  const full = axis === 'pan' ? 270 : 90;
  const dmx = Math.round((deg / full) * 128);
  return Math.max(0, Math.min(128, dmx));
}

// Mapping: section → best suited movement patterns per fixture (ordered by energy)
export const SMART_MOVEMENTS: Record<string, string[]> = {
  intro:   ['static', 'panOnly', 'tiltOnly', 'sweep', 'wave'],
  verse:   ['sweep', 'wave', 'panOnly', 'figure8', 'randomWalk', 'panOnly'],
  chorus:  ['circle', 'sweep', 'spiral', 'diamond', 'figure8', 'bounce', 'wave'],
  bridge:  ['figure8', 'wave', 'zigzag', 'randomWalk', 'spiral', 'diamond'],
  drop:    ['bounce', 'zigzag', 'heartbeat', 'circle', 'spiral', 'diamond', 'randomWalk', 'wave'],
  outro:   ['tiltOnly', 'panOnly', 'sweep', 'static', 'wave'],
  build:   ['spiral', 'circle', 'wave', 'sweep', 'diamond', 'zigzag'],
};

export const DEFAULT_SMART_MOVEMENTS = ['sweep', 'circle', 'wave', 'figure8', 'zigzag'];

export function getSmartMovement(
  fixtureIndex: number,
  totalMobileFixtures: number,
  section: string,
  timeOffset?: number,
): string {
  const patterns = SMART_MOVEMENTS[section] || DEFAULT_SMART_MOVEMENTS;
  if (totalMobileFixtures <= 1) return patterns[0];
  let hash = 0;
  for (let i = 0; i < section.length; i++) hash = ((hash << 5) - hash) + section.charCodeAt(i);
  const timeIdx = timeOffset ? Math.floor(timeOffset / 8) : 0;
  const idx = (fixtureIndex + timeIdx + Math.abs(hash % 97)) % patterns.length;
  return patterns[idx];
}

// ---- Spatial choreography -------------------------------------------------
// Per-fixture phase offsets derived from real stage positions (x,y normalized 0..1).
// Turns a uniform movement pattern into a wave/circle/expand across the whole rig.

export type SpatialPattern = 'off' | 'wave' | 'circle' | 'expand' | 'contract' | 'alternate';

export const SPATIAL_BY_SECTION: Record<string, SpatialPattern> = {
  intro:   'wave',
  verse:   'wave',
  chorus:  'circle',
  bridge:  'wave',
  drop:    'expand',
  outro:   'contract',
  build:   'alternate',
};

/** Fallback stage position: same grid formula as showStore.initFixturePosition. */
export function fallbackPosition(mobileIdx: number): { x: number; y: number } {
  const col = mobileIdx % 6;
  const row = Math.floor(mobileIdx / 6);
  return { x: 0.1 + col * 0.16, y: 0.1 + row * 0.18 };
}

/**
 * Per-fixture phase offset (radians) for a spatial pattern, added to the movement phase.
 * - wave:      phase ~ -x   -> cascade sweeping left to right (lambda = full stage)
 * - circle:    phase ~ +x   -> rotating ring along the line (Lissajous circle)
 * - expand:    phase ~ -dist to center -> impulse from center to the edges (drop)
 * - contract:  phase ~ +dist to center -> converge toward the center (outro)
 * - alternate: pi on odd mobile index -> alternating pair/impair groups (build)
 * Missing position -> grid fallback by index. Unknown/off -> 0 (current behavior).
 */
export function spatialPhaseFor(
  pos: { x: number; y: number } | undefined,
  pattern: string | undefined,
  mobileIdx: number,
): number {
  if (!pattern || pattern === 'off') return 0;
  if (pattern === 'alternate') return mobileIdx % 2 === 0 ? 0 : Math.PI;
  const p = pos ?? fallbackPosition(Math.max(0, mobileIdx));
  const cx = p.x - 0.5;
  const cy = p.y - 0.5;
  switch (pattern) {
    case 'wave': return -Math.PI * 2 * cx;
    case 'circle': return Math.PI * 2 * cx;
    case 'expand': return -Math.PI * 2 * Math.sqrt(cx * cx + cy * cy);
    case 'contract': return Math.PI * 2 * Math.sqrt(cx * cx + cy * cy);
    default: return 0;
  }
}
